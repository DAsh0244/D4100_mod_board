## WEBENCH Design 17
Created at Thu Jun 27 12:15:51 PDT 2019
**********************************************************
***************** Schematic Instructions  ****************
**********************************************************

To import your new Schematic into Orcad Capture CIS:

1. Unzip the downloaded folder files to a local directory and 
   Start Orcad Capture CIS.
2. Select File\Import Design from the menu.
3. Select the EDIF tab.
4. Browse to the correct EDIF file in the "Open" Window.  Note that it will not see
    the "edif " directory by default.
5. Verify remaining settings.  If you do not have a configuration file already
   you can (and really should) use the one provided with your exported files.
6. Press Okay.

A Schematic will be imported for you.  Use File\Open\Design from the menu to view your Schematic.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/OrcadCapture_BrdSch_import.html

**********************************************************
*******************  PCB Instructions  *******************
**********************************************************

To import your new Board into Allegro:

1. Unzip the downloaded folder files to a local directory and 
   Using your Windows explorer, find the file that was included
   in your zip file that ends in ".bat".  This is a batch file
   set of instructions for your computer.  Double clicking this
   file should start the batch file.  You must already have Allegro
   installed on the computer that the batch file was
   created on, or you will need to modify the pathing of the
   batch file.
2. Use the Allegro PCB Design L (legacy) environment to open the PCB layout.
   Be patient as it may take several minutes for Allegro execute the
   ".bat" file. If issues occur because of compatibility between releases,
   click "Yes" to proceed to the next process. If this happens once, it will
   happen for every footprint created and hault the ".bat" execution.
3. It will create more files for you by first loading the
   padstack tool, and then the part building software.  The parts
   will all be located in the directory the batch file was executed from
   and will contain both the .DRA file, the .PSM file and any
   other associated entities (like flash files and padstacks).
4. After the parts are built a board will be created, parts placed and
   traces, vias, etc installed.  Once the board is completely built
   the program will exit.
5. You will need to open Allegro up again and set your global
   plane clearances and contact styles per your requirements.  In the case
   of planes that are part of the library (such as under an SON style part)
   you may need to create the planes manually and delete them from the
   components.
6. Once completed, you will want to move the files that have
   been created to your appropriate directory structure, so that
   the parts are available for use in your board.

This requires that you have Allegro installed in the normal
locations and that it can be found in your pathing. If this
is not the case, simply edit the lines in your batch file that
refer to your Allegro tools to find them in the correct location.

You may be running a newer version of the Allegro Software than the
template file we are distributing.  In this case you will be asked
to okay the loading of the file each time the script requires a
file load.  You can update the template files found in the
\installationpath\CadInfos\Allegro\*.pcb files by simply opening
them in Allegro and then saving them again in your current version
of Allegro.  You should do this with the *.dra files as well.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Allegro_import.html

Additionally, this video may be helpful:
http://youtu.be/d1ixNGZUKjQ


**********************************************************
*******************  SIMULATION Instructions  ************
**********************************************************

This XML can be imported in Cadence Allegro using WEBENCH Allegro Connector 
and simulated using WEBENCH Simulation Engine. The WEBENCH Allegro Connector 
provides an interface to the Texas Instruments WEBENCH Designer Tools as well 
as to open WEBENCH exported Designs directly from inside Allegro.

It also includes the advanced WEBENCH Simulation Engine which can be used for 
offline circuit simulations. You will need a activation key from TI to be able 
to use the WEBENCH Simulation Engine.

Download WEBENCH Allegro Connector:
http://www.ti.com/lit/zip/SNAC066

Installation guide:
http://www.ti.com/lit/SNVU482

Connector Details:
http://www.ti.com/lsds/ti/analog/webench/allegroconnector.page

More about WEBENCH simulation export to Altium:
http://www.ti.com/lsds/ti/analog/webench/simexportorcad.page

