 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: Z:\\44\\82\\4482731\\7\Eagle\2019-06-19_12-44-52\2019-06-19_12-44-52.xml
 
 
**********************************************************
*****************Schematic Instructions  *******************
**********************************************************

To import your new Schematic file into Eagle:

1. Unzip the downloaded folder files to local directory and Start Eagle.
2. Select "File"->"Open"->"Schematic..." from the menu at the top of
the screen.
3. Browse to your newly exported file and select the ".sch" file extension.
4. You should now see your schamtic available in Eagle.

**********************************************************
*******************  PCB Instructions  *******************
**********************************************************

To import your new BOARD file into Eagle:

1. Unzip the downloaded folder files to local directory and Start Eagle.
2. Select "File"->"Open"->"Board..." from the menu at the top of
the screen.
3. Browse to your newly exported file and select the ".brd" file extension.
4. Planes will need to be repoured to update the polygon fills
	1. Once your board is loaded, type "ratsnest" into the command
	   line and press the Enter key.
	2. The polygons should all be filled now.
5. You should now have an image of your board available in Eagle.

**********************************************************
*******************  LIB Instructions  *******************
**********************************************************

To import your new library into Eagle:

1. Start Eagle.
2. Select "File"->"New"->"Library" from the menu.
3. In the blank library window, select "File" -> "Execute Script"
from the menu.
5. Browse to your newly exported Eagle Script file (".scr" file extension)
6. After opening the file, the script will populate the new library.
Layer 93 should NOT exist.
7. Use "File"->Save As: "AcceleratedDesigns_Lib.lbr" and to the desired
location in Eagle native format.
8. Update schematic with the imported library, Select Library and click on Update; open the library file
	and sync. each part.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Eagle_import.html

You may also find this video helpful:
http://youtu.be/5jGuWY-Yy3Q

**********************************************************
**********************************************************
**********************************************************
 
 
Padstack "RX62p99Y11p81D0TSM2" renamed to "RX62p99Y11p81D00"
Padstack "RX118p11Y118p11D0T" renamed to "RX118p11Y118p11D"
Symbol "WB_COMPENSATION_BLOCK_TYPE3_VERT" renamed to "WB_COMPENSATION_BLOCK_TYPE3_VE"
Component "CRCW04021K65FKED" renamed to "CRCW04021K65FKED"
Component "RT0805BRD0727K7L" renamed to "RT0805BRD0727K7L"
Component "LM25088MH-1/NOPB" renamed to "LM25088MH-1/NOPB"
Component "CRCW04023K57FKED" renamed to "CRCW04023K57FKED"
Component "CRCW060341K2FKEA" renamed to "CRCW060341K2FKEA"
Component "C2012X5R1H225K125AB" renamed to "C2012X5R1H225K125AB"
Component "GRM1555C1H511GA01D" renamed to "GRM1555C1H511GA01D"
Component "WB_GND" renamed to "WB_GND"
Component "C1608X5R1H684K080AB" renamed to "C1608X5R1H684K080AB"
Component "CSD18543Q3A" renamed to "CSD18543Q3A"
Component "GRM033R60J223KE01D" renamed to "GRM033R60J223KE01D"
Component "EMK107B7105KA-T" renamed to "EMK107B7105KA-T"
Component "B560C-13-F" renamed to "B560C-13-F"
Component "CL10C301JB8NNNC" renamed to "CL10C301JB8NNNC"
Component "MLC1565-372MLB" renamed to "MLC1565-372MLB"
Component "RC0201FR-0710KL" renamed to "RC0201FR-0710KL"
Component "WB_CURRENT_LOAD" renamed to "WB_CURRENT_LOAD"
Component "TMK212BJ474KD-T" renamed to "TMK212BJ474KD-T"
Component "RC0603FR-077K87L" renamed to "RC0603FR-077K87L"
Component "CL21C331JBANNNC" renamed to "CL21C331JBANNNC"
Component "GRM155R71C104KA88D" renamed to "GRM155R71C104KA88D"
Component "C0805C106K8PACTU" renamed to "C0805C106K8PACTU"
Component "CRCW040235K7FKED" renamed to "CRCW040235K7FKED"
Component "PRL1632-R006-F-T1" renamed to "PRL1632-R006-F-T1"
Component "GRM155R71E333KA88D" renamed to "GRM155R71E333KA88D"
Component "RC0201FR-0718K7L" renamed to "RC0201FR-0718K7L"
Component "GRM0335C1H111JA01D" renamed to "GRM0335C1H111JA01D"
Component "WB_BATTERY" renamed to "WB_BATTERY"
Component "50SVPF18M" renamed to "50SVPF18M"
The Symbol WB_CONTINUATION was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CONTINUATION was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CONTINUATION was missing a Value attribute, a value was created for the symbol.
The Symbol WB_BLOCK_IO was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Type attribute, a type was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Value attribute, a value was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a Value attribute, a value was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LM25088 was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LM25088 was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LM25088 was missing a Value attribute, a value was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE1 was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE1 was missing a Type attribute, a type was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE1 was missing a Value attribute, a value was created for the symbol.
The Symbol WB_N_MOSFET was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_N_MOSFET was missing a Type attribute, a type was created for the symbol.
The Symbol WB_N_MOSFET was missing a Value attribute, a value was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE3_VE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE3_VE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE3_VE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE2 was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE2 was missing a Type attribute, a type was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE2 was missing a Value attribute, a value was created for the symbol.


Ultra Librarian Gold 8.1.204 Process Report


Message - Padstack "RX22Y24D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX62p99Y11p81D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX62p99Y11p81D00" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX118p11Y118p11D" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX26Y38D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX44Y57D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "R10160280000202A" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "R10991000004949A" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX14Y13D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX71Y117D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX196p5Y134D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX22Y132D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX140Y32D0T" Shape(4) is a CIRCLE with no diameter.
Message - Symbol "WB_CAPACITOR" has as multiple attributes named "TYPE".
One of the attributes was renamed to "TYPE_2".
Message - Component "CRCW04021K65FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04021K65FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04021K65FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RT0805BRD0727K7L" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RT0805BRD0727K7L" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RT0805BRD0727K7L" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1/NOPB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1/NOPB" attribute "Frequency" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1/NOPB" attribute "Imax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1/NOPB" attribute "Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1/NOPB" attribute "Mktg_Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1/NOPB" attribute "NSID" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04023K57FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04023K57FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04023K57FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW060341K2FKEA" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW060341K2FKEA" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW060341K2FKEA" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1H225K125AB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1H225K125AB" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1H225K125AB" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1H225K125AB" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1H225K125AB" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM1555C1H511GA01D" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM1555C1H511GA01D" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM1555C1H511GA01D" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM1555C1H511GA01D" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM1555C1H511GA01D" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H684K080AB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H684K080AB" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H684K080AB" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H684K080AB" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H684K080AB" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18543Q3A" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18543Q3A" attribute "VdsMax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18543Q3A" attribute "IdsMax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18543Q3A" attribute "Rdson45" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18543Q3A" attribute "QgTyp" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18543Q3A" attribute "Quantity" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R60J223KE01D" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R60J223KE01D" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R60J223KE01D" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R60J223KE01D" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK107B7105KA-T" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK107B7105KA-T" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK107B7105KA-T" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK107B7105KA-T" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK107B7105KA-T" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "B560C-13-F" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "B560C-13-F" attribute "Io" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "B560C-13-F" attribute "VRRM" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "B560C-13-F" attribute "VFatIo" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL10C301JB8NNNC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL10C301JB8NNNC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL10C301JB8NNNC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL10C301JB8NNNC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL10C301JB8NNNC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "MLC1565-372MLB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "MLC1565-372MLB" attribute "L" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "MLC1565-372MLB" attribute "DCR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "MLC1565-372MLB" attribute "IDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0710KL" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0710KL" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0710KL" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0710KL" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TMK212BJ474KD-T" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TMK212BJ474KD-T" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TMK212BJ474KD-T" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TMK212BJ474KD-T" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0603FR-077K87L" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0603FR-077K87L" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0603FR-077K87L" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C331JBANNNC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C331JBANNNC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C331JBANNNC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C331JBANNNC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C331JBANNNC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71C104KA88D" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71C104KA88D" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71C104KA88D" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71C104KA88D" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C106K8PACTU" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C106K8PACTU" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C106K8PACTU" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C106K8PACTU" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040235K7FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040235K7FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040235K7FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PRL1632-R006-F-T1" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PRL1632-R006-F-T1" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PRL1632-R006-F-T1" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PRL1632-R006-F-T1" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71E333KA88D" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71E333KA88D" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71E333KA88D" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71E333KA88D" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0718K7L" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0718K7L" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0718K7L" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0718K7L" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM0335C1H111JA01D" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM0335C1H111JA01D" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM0335C1H111JA01D" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM0335C1H111JA01D" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM0335C1H111JA01D" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "50SVPF18M" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "50SVPF18M" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "50SVPF18M" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "50SVPF18M" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "50SVPF18M" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.

TextStyle count:  24
Padstack count:   13
Pattern count:    10
Symbol count:     21
Component count:  29

Export


Footprint "WB_GND" has no layer data mapped and will be skipped.
Component "WB_GND" requires footprint "WB_GND" and will be skipped.
Footprint "WB_CURRENT_LOAD" has no layer data mapped and will be skipped.
Component "WB_CURRENT_LOAD" requires footprint "WB_CURRENT_LOAD" and will be skipped.
Footprint "WB_BATTERY" has no layer data mapped and will be skipped.
Component "WB_BATTERY" requires footprint "WB_BATTERY" and will be skipped.
