 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: Z:\\44\\82\\4482731\\7\Altium\2019-06-19_12-45-08\2019-06-19_12-45-08
 
 
**********************************************************
***************** Schematic Instructions  ****************
**********************************************************

To import your new Schematic into Altium:

1. Unzip the downloaded folder files to a local directory and
Start the Altium program.
2. From the menu select "File"->"Open".
3. Select the file named in the path above ending with ".schdoc"
and "Open" the file.
4. Your Schematic should be viewable within Altium now.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_BrdSch_import.html



**********************************************************
*******************  PCB Instructions  *******************
**********************************************************


To import your new BOARD into Altium:

1. Unzip the downloaded folder files to a local directory
	and Start the Altium program.
2. From the menu select "File"->"Open".
3. Select the file named in the path above ending with ".pcbdoc"
and "Open" the file.
4. Planes will need to be repoured to update the Copper Pour Polygons
	a. Once your board is loaded, select the Tools menu from the
	   top Menu Bar
	b. Scroll to the Polygon Pours item on the Tools Menu.
	c. The Polygon Pours item should expand to show more options
	d. Select Repour All Polygons, this will repour all of the
	   polygons.
5. Your board should be viewable within Altium now.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_BrdSch_import.html

**********************************************************
*******************  LIB Instructions  *******************
**********************************************************

To import your new LIBRARY PARTS into Altium follow these steps:

1. After running the Ultra Librarian export for the first time,
you will need to copy the following files into an area where
they can be accessed for all future translations.  They are script
files that Altium will need to be able to find.
	a. UL_Form.dfm
	b. UL_Form.pas
	c. UL_Import.pas
	d. UL_Import.prjScr
2. The above script file will need to be run from within Altium.
This can be done by going to File, Open and selecting the
UL_Import.PrjScr file stored above.
3. Select the "DXP" dropdown menu in the top-left corner runfrom
the drop down menu and select "Run Script". Select "UL_Form.pas"
and click "OK"
4. When the script is run, it will ask you for the file name of the
Ultra Librarian file to run. Click "File...", select the latest file
produced with a date code (for instance 2010-02-17_23-12-34.txt), and
click "Start Import".
5. The script will open a new Integraged Library project and import
the Ultra Librarian data into it.  When complete a message box
will pop up saying that import is done.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Altium_import.html

For a video tutorial, please visit:
http://youtu.be/pih50yx9HYU

**********************************************************
**********************************************************
**********************************************************
 
 
Padstack "RX62p99Y11p81D0TSM2" renamed to "RX62p99Y11p81D00"
Padstack "RX118p11Y118p11D0T" renamed to "RX118p11Y118p11D"
Symbol "WB_SOURCE_RESISTOR" renamed to "WB_SOURCE_RESIST"
Symbol "WB_PRIMITIVE_BATTERY" renamed to "WB_PRIMITIVE_BAT"
Symbol "WB_COMPENSATION_BLOCK_TYPE1" renamed to "WB_COMPENSATION_"
Symbol "WB_DIODE_SCHOTTKY" renamed to "WB_DIODE_SCHOTTK"
Symbol "WB_COMPENSATION_BLOCK_TYPE3_VERT" renamed to "WB_COMPENSATIO00"
Symbol "WB_COMPENSATION_BLOCK_TYPE2" renamed to "WB_COMPENSATIO01"
Component "CRCW04021K65FKED" renamed to "CRCW04021K65FKED"
Component "RT0805BRD0727K7L" renamed to "RT0805BRD0727K7L"
Component "LM25088MH-1/NOPB" renamed to "LM25088MH-1/NOPB"
Component "CRCW04023K57FKED" renamed to "CRCW04023K57FKED"
Component "CRCW060341K2FKEA" renamed to "CRCW060341K2FKEA"
Component "C2012X5R1H225K125AB" renamed to "C2012X5R1H225K12"
Component "GRM1555C1H511GA01D" renamed to "GRM1555C1H511GA0"
Component "WB_GND" renamed to "WB_GND"
Component "C1608X5R1H684K080AB" renamed to "C1608X5R1H684K08"
Component "CSD18543Q3A" renamed to "CSD18543Q3A"
Component "GRM033R60J223KE01D" renamed to "GRM033R60J223KE0"
Component "EMK107B7105KA-T" renamed to "EMK107B7105KA-T"
Component "B560C-13-F" renamed to "B560C-13-F"
Component "CL10C301JB8NNNC" renamed to "CL10C301JB8NNNC"
Component "MLC1565-372MLB" renamed to "MLC1565-372MLB"
Component "RC0201FR-0710KL" renamed to "RC0201FR-0710KL"
Component "WB_CURRENT_LOAD" renamed to "WB_CURRENT_LOAD"
Component "TMK212BJ474KD-T" renamed to "TMK212BJ474KD-T"
Component "RC0603FR-077K87L" renamed to "RC0603FR-077K87L"
Component "CL21C331JBANNNC" renamed to "CL21C331JBANNNC"
Component "GRM155R71C104KA88D" renamed to "GRM155R71C104KA8"
Component "C0805C106K8PACTU" renamed to "C0805C106K8PACTU"
Component "CRCW040235K7FKED" renamed to "CRCW040235K7FKED"
Component "PRL1632-R006-F-T1" renamed to "PRL1632-R006-F-T"
Component "GRM155R71E333KA88D" renamed to "GRM155R71E333KA8"
Component "RC0201FR-0718K7L" renamed to "RC0201FR-0718K7L"
Component "GRM0335C1H111JA01D" renamed to "GRM0335C1H111JA0"
Component "WB_BATTERY" renamed to "WB_BATTERY"
Component "50SVPF18M" renamed to "50SVPF18M"
The Symbol WB_CONTINUATION was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CONTINUATION was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CONTINUATION was missing a Value attribute, a value was created for the symbol.
The Symbol WB_BLOCK_IO was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Type attribute, a type was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Value attribute, a value was created for the symbol.
The Symbol WB_SOURCE_RESIST was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_SOURCE_RESIST was missing a Type attribute, a type was created for the symbol.
The Symbol WB_SOURCE_RESIST was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_BAT was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIMITIVE_BAT was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_BAT was missing a Value attribute, a value was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LM25088 was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LM25088 was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LM25088 was missing a Value attribute, a value was created for the symbol.
The Symbol WB_COMPENSATION_ was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_COMPENSATION_ was missing a Type attribute, a type was created for the symbol.
The Symbol WB_COMPENSATION_ was missing a Value attribute, a value was created for the symbol.
The Symbol WB_N_MOSFET was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_N_MOSFET was missing a Type attribute, a type was created for the symbol.
The Symbol WB_N_MOSFET was missing a Value attribute, a value was created for the symbol.
The Symbol WB_COMPENSATIO00 was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_COMPENSATIO00 was missing a Type attribute, a type was created for the symbol.
The Symbol WB_COMPENSATIO00 was missing a Value attribute, a value was created for the symbol.
The Symbol WB_COMPENSATIO01 was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_COMPENSATIO01 was missing a Type attribute, a type was created for the symbol.
The Symbol WB_COMPENSATIO01 was missing a Value attribute, a value was created for the symbol.


Ultra Librarian Gold 8.1.204 Process Report


Message - Symbol "WB_CAPACITOR" has as multiple attributes named "TYPE".
One of the attributes was renamed to "TYPE_2".
Message - Component "CRCW04021K65FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04021K65FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04021K65FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RT0805BRD0727K7L" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RT0805BRD0727K7L" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RT0805BRD0727K7L" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1/NOPB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1/NOPB" attribute "Frequency" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1/NOPB" attribute "Imax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1/NOPB" attribute "Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1/NOPB" attribute "Mktg_Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1/NOPB" attribute "NSID" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04023K57FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04023K57FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04023K57FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW060341K2FKEA" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW060341K2FKEA" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW060341K2FKEA" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1H225K12" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1H225K12" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1H225K12" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1H225K12" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1H225K12" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM1555C1H511GA0" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM1555C1H511GA0" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM1555C1H511GA0" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM1555C1H511GA0" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM1555C1H511GA0" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H684K08" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H684K08" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H684K08" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H684K08" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H684K08" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18543Q3A" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18543Q3A" attribute "VdsMax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18543Q3A" attribute "IdsMax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18543Q3A" attribute "Rdson45" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18543Q3A" attribute "QgTyp" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18543Q3A" attribute "Quantity" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R60J223KE0" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R60J223KE0" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R60J223KE0" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R60J223KE0" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK107B7105KA-T" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK107B7105KA-T" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK107B7105KA-T" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK107B7105KA-T" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK107B7105KA-T" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "B560C-13-F" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "B560C-13-F" attribute "Io" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "B560C-13-F" attribute "VRRM" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "B560C-13-F" attribute "VFatIo" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL10C301JB8NNNC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL10C301JB8NNNC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL10C301JB8NNNC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL10C301JB8NNNC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL10C301JB8NNNC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "MLC1565-372MLB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "MLC1565-372MLB" attribute "L" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "MLC1565-372MLB" attribute "DCR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "MLC1565-372MLB" attribute "IDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0710KL" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0710KL" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0710KL" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0710KL" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TMK212BJ474KD-T" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TMK212BJ474KD-T" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TMK212BJ474KD-T" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TMK212BJ474KD-T" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0603FR-077K87L" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0603FR-077K87L" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0603FR-077K87L" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C331JBANNNC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C331JBANNNC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C331JBANNNC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C331JBANNNC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C331JBANNNC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71C104KA8" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71C104KA8" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71C104KA8" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71C104KA8" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C106K8PACTU" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C106K8PACTU" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C106K8PACTU" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C106K8PACTU" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040235K7FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040235K7FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040235K7FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PRL1632-R006-F-T" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PRL1632-R006-F-T" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PRL1632-R006-F-T" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PRL1632-R006-F-T" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71E333KA8" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71E333KA8" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71E333KA8" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71E333KA8" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0718K7L" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0718K7L" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0718K7L" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0718K7L" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM0335C1H111JA0" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM0335C1H111JA0" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM0335C1H111JA0" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM0335C1H111JA0" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM0335C1H111JA0" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "50SVPF18M" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "50SVPF18M" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "50SVPF18M" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "50SVPF18M" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "50SVPF18M" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.

TextStyle count:  24
Padstack count:   13
Pattern count:    10
Symbol count:     21
Component count:  29

Export

Footprint "0402" has no layer data mapped and will be skipped.
Component "CRCW04021K65FKED" requires footprint "0402" and will be skipped.
Component "CRCW04023K57FKED" requires footprint "0402" and will be skipped.
Component "GRM1555C1H511GA0" requires footprint "0402" and will be skipped.
Component "GRM155R71C104KA8" requires footprint "0402" and will be skipped.
Component "CRCW040235K7FKED" requires footprint "0402" and will be skipped.
Component "GRM155R71E333KA8" requires footprint "0402" and will be skipped.
Footprint "0603" has no layer data mapped and will be skipped.
Component "CRCW060341K2FKEA" requires footprint "0603" and will be skipped.
Component "C1608X5R1H684K08" requires footprint "0603" and will be skipped.
Component "EMK107B7105KA-T" requires footprint "0603" and will be skipped.
Component "CL10C301JB8NNNC" requires footprint "0603" and will be skipped.
Component "RC0603FR-077K87L" requires footprint "0603" and will be skipped.
Footprint "0805" has no layer data mapped and will be skipped.
Component "RT0805BRD0727K7L" requires footprint "0805" and will be skipped.
Component "C2012X5R1H225K12" requires footprint "0805" and will be skipped.
Component "TMK212BJ474KD-T" requires footprint "0805" and will be skipped.
Component "CL21C331JBANNNC" requires footprint "0805" and will be skipped.
Component "C0805C106K8PACTU" requires footprint "0805" and will be skipped.
Footprint "0201" has no layer data mapped and will be skipped.
Component "GRM033R60J223KE0" requires footprint "0201" and will be skipped.
Component "RC0201FR-0710KL" requires footprint "0201" and will be skipped.
Component "RC0201FR-0718K7L" requires footprint "0201" and will be skipped.
Component "GRM0335C1H111JA0" requires footprint "0201" and will be skipped.
Warning: Symbol "LM25088MH-1" attribute "PN" references missing text style ""
Warning: Symbol "LM25088MH-1" attribute "DEV" references missing text style ""
Warning: Symbol "LM25088MH-1" attribute "VAL" references missing text style ""
Warning: Symbol "LM25088MH-1" attribute "TOL" references missing text style ""
Warning: Symbol "LM25088MH-1" attribute "RefDes2" references missing text style ""
Warning: Symbol "CSD18543Q3A" attribute "TOL" references missing text style ""
Warning: Symbol "CSD18543Q3A" attribute "VAL" references missing text style ""
Warning: Symbol "CSD18543Q3A" attribute "DEV" references missing text style ""
Warning: Symbol "CSD18543Q3A" attribute "PN" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "Io" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "VRRM" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "VFatIo" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "PN" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "DEV" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "VAL" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "TOL" references missing text style ""
Warning: Symbol "WB_DIODE_SCHOTTK" attribute "RefDes2" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "L" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "DCR" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "IDC" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_INDUCTOR" attribute "RefDes2" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Resistance" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Power" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "Tolerance" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "PN" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "DEV" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "VAL" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "TOL" references missing text style ""
Warning: Symbol "WB_RESISTOR" attribute "RefDes2" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "Cap" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "ESR" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "IRMS" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "VDC" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "PN" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "DEV" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "VAL" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "TOL" references missing text style ""
Warning: Symbol "WB_CAP_POLARIZED" attribute "RefDes2" references missing text style ""
