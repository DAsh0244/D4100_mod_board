 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: Z:\\44\\82\\4482731\\7\Allegro\2019-06-19_12-45-19\2019-06-19_12-45-19
 
 
**********************************************************
*******************  PCB Instructions  *******************
**********************************************************

To import your new Board into Allegro:

1. Unzip the downloaded folder files to a local directory and
Using your Windows explorer, find the file that was included
in your zip file that ends in ".bat".  This is a batch file
set of instructions for your computer.  Double clicking this
file should start the batch file.  You must already have Allegro
installed on the computer that the batch file was
created on, or you will need to modify the pathing of the
batch file.
2. Use the Allegro PCB Design L (legacy) environment to open the PCB layout.
Be patient as it may take several minutes for Allegro execute the
".bat" file. If issues occur because of compatibility between releases,
click "Yes" to proceed to the next process. If this happens once, it will
happen for every footprint created and hault the ".bat" execution.
3. It will create more files for you by first loading the
padstack tool, and then the part building software.  The parts
will all be located in the directory the batch file was executed from
and will contain both the .DRA file, the .PSM file and any
other associated entities (like flash files and padstacks).
4. After the parts are built a board will be created, parts placed and
traces, vias, etc installed.  Once the board is completely built
the program will exit.
5. You will need to open Allegro up again and set your global
plane clearances and contact styles per your requirements.  In the case
of planes that are part of the library (such as under an SON style part)
you may need to create the planes manually and delete them from the
components.
6. Once completed, you will want to move the files that have
been created to your appropriate directory structure, so that
the parts are available for use in your board.

This requires that you have Allegro installed in the normal
locations and that it can be found in your pathing. If this
is not the case, simply edit the lines in your batch file that
refer to your Allegro tools to find them in the correct location.

You may be running a newer version of the Allegro Software than the
template file we are distributing.  In this case you will be asked
to okay the loading of the file each time the script requires a
file load.  You can update the template files found in the
\installationpath\CadInfos\Allegro\*.pcb files by simply opening
them in Allegro and then saving them again in your current version
of Allegro.  You should do this with the *.dra files as well.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Allegro_import.html

Additionally, this video may be helpful:
http://youtu.be/d1ixNGZUKjQ

**********************************************************
**********************************************************
**********************************************************
 
 
Padstack "RX62p99Y11p81D0TSM2" renamed to "RX62p99Y11p81D0TSM"
Component "CRCW04021K65FKED" renamed to "CRCW04021K65FKED"
Component "RT0805BRD0727K7L" renamed to "RT0805BRD0727K7L"
Component "LM25088MH-1/NOPB" renamed to "LM25088MH-1NOPB"
Component "CRCW04023K57FKED" renamed to "CRCW04023K57FKED"
Component "CRCW060341K2FKEA" renamed to "CRCW060341K2FKEA"
Component "C2012X5R1H225K125AB" renamed to "C2012X5R1H225K125AB"
Component "GRM1555C1H511GA01D" renamed to "GRM1555C1H511GA01D"
Component "WB_GND" renamed to "WB_GND"
Component "C1608X5R1H684K080AB" renamed to "C1608X5R1H684K080AB"
Component "CSD18543Q3A" renamed to "CSD18543Q3A"
Component "GRM033R60J223KE01D" renamed to "GRM033R60J223KE01D"
Component "EMK107B7105KA-T" renamed to "EMK107B7105KA-T"
Component "B560C-13-F" renamed to "B560C-13-F"
Component "CL10C301JB8NNNC" renamed to "CL10C301JB8NNNC"
Component "MLC1565-372MLB" renamed to "MLC1565-372MLB"
Component "RC0201FR-0710KL" renamed to "RC0201FR-0710KL"
Component "WB_CURRENT_LOAD" renamed to "WB_CURRENT_LOAD"
Component "TMK212BJ474KD-T" renamed to "TMK212BJ474KD-T"
Component "RC0603FR-077K87L" renamed to "RC0603FR-077K87L"
Component "CL21C331JBANNNC" renamed to "CL21C331JBANNNC"
Component "GRM155R71C104KA88D" renamed to "GRM155R71C104KA88D"
Component "C0805C106K8PACTU" renamed to "C0805C106K8PACTU"
Component "CRCW040235K7FKED" renamed to "CRCW040235K7FKED"
Component "PRL1632-R006-F-T1" renamed to "PRL1632-R006-F-T1"
Component "GRM155R71E333KA88D" renamed to "GRM155R71E333KA88D"
Component "RC0201FR-0718K7L" renamed to "RC0201FR-0718K7L"
Component "GRM0335C1H111JA01D" renamed to "GRM0335C1H111JA01D"
Component "WB_BATTERY" renamed to "WB_BATTERY"
Component "50SVPF18M" renamed to "50SVPF18M"
The Symbol WB_CONTINUATION was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CONTINUATION was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CONTINUATION was missing a Value attribute, a value was created for the symbol.
The Symbol WB_BLOCK_IO was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Type attribute, a type was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Value attribute, a value was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a Value attribute, a value was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LM25088 was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LM25088 was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LM25088 was missing a Value attribute, a value was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE1 was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE1 was missing a Type attribute, a type was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE1 was missing a Value attribute, a value was created for the symbol.
The Symbol WB_N_MOSFET was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_N_MOSFET was missing a Type attribute, a type was created for the symbol.
The Symbol WB_N_MOSFET was missing a Value attribute, a value was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE3_VERT was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE3_VERT was missing a Type attribute, a type was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE3_VERT was missing a Value attribute, a value was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE2 was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE2 was missing a Type attribute, a type was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE2 was missing a Value attribute, a value was created for the symbol.


Ultra Librarian Gold 8.1.204 Process Report


Message - Symbol "WB_CAPACITOR" has as multiple attributes named "TYPE".
One of the attributes was renamed to "TYPE_2".
Message - Component "CRCW04021K65FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04021K65FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04021K65FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RT0805BRD0727K7L" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RT0805BRD0727K7L" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RT0805BRD0727K7L" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1NOPB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1NOPB" attribute "Frequency" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1NOPB" attribute "Imax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1NOPB" attribute "Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1NOPB" attribute "Mktg_Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1NOPB" attribute "NSID" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04023K57FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04023K57FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04023K57FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW060341K2FKEA" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW060341K2FKEA" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW060341K2FKEA" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1H225K125AB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1H225K125AB" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1H225K125AB" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1H225K125AB" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C2012X5R1H225K125AB" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM1555C1H511GA01D" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM1555C1H511GA01D" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM1555C1H511GA01D" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM1555C1H511GA01D" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM1555C1H511GA01D" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H684K080AB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H684K080AB" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H684K080AB" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H684K080AB" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H684K080AB" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18543Q3A" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18543Q3A" attribute "VdsMax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18543Q3A" attribute "IdsMax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18543Q3A" attribute "Rdson45" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18543Q3A" attribute "QgTyp" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CSD18543Q3A" attribute "Quantity" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R60J223KE01D" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R60J223KE01D" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R60J223KE01D" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R60J223KE01D" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK107B7105KA-T" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK107B7105KA-T" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK107B7105KA-T" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK107B7105KA-T" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "EMK107B7105KA-T" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "B560C-13-F" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "B560C-13-F" attribute "Io" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "B560C-13-F" attribute "VRRM" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "B560C-13-F" attribute "VFatIo" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL10C301JB8NNNC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL10C301JB8NNNC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL10C301JB8NNNC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL10C301JB8NNNC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL10C301JB8NNNC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "MLC1565-372MLB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "MLC1565-372MLB" attribute "L" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "MLC1565-372MLB" attribute "DCR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "MLC1565-372MLB" attribute "IDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0710KL" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0710KL" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0710KL" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0710KL" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TMK212BJ474KD-T" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TMK212BJ474KD-T" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TMK212BJ474KD-T" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "TMK212BJ474KD-T" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0603FR-077K87L" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0603FR-077K87L" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0603FR-077K87L" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C331JBANNNC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C331JBANNNC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C331JBANNNC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C331JBANNNC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL21C331JBANNNC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71C104KA88D" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71C104KA88D" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71C104KA88D" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71C104KA88D" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C106K8PACTU" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C106K8PACTU" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C106K8PACTU" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0805C106K8PACTU" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040235K7FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040235K7FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040235K7FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PRL1632-R006-F-T1" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PRL1632-R006-F-T1" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PRL1632-R006-F-T1" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PRL1632-R006-F-T1" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71E333KA88D" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71E333KA88D" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71E333KA88D" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71E333KA88D" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0718K7L" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0718K7L" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0718K7L" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0718K7L" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM0335C1H111JA01D" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM0335C1H111JA01D" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM0335C1H111JA01D" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM0335C1H111JA01D" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM0335C1H111JA01D" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "50SVPF18M" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "50SVPF18M" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "50SVPF18M" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "50SVPF18M" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "50SVPF18M" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.

TextStyle count:  24
Padstack count:   13
Pattern count:    10
Symbol count:     21
Component count:  29

Export

Starting to Export Allegro Padstacks
Starting to Export Allegro Parts
Exporting 0402
Exporting MXA16A
Exporting 0603
Exporting 0805
Exporting DNH0008A
Exporting 0201
Exporting SMC
Exporting MLC1565
Exporting 0612
Exporting CAPSMT_62_E7
Completing output of Allegro netlist, placement and device files
