To import your new Schematic into Orcad Capture CIS:

1. Unzip the downloaded folder files to a local directory and 
   Start Orcad Capture CIS.
2. Select File\Import Design from the menu.
3. Select the EDIF tab.
4. Browse to the correct EDIF file in the "Open" Window.  Note that it will not see
    the "edif " directory by default.
5. Verify remaining settings.  If you do not have a configuration file already
   you can (and really should) use the one provided with your exported files.
6. Press Okay.

A Schematic will be imported for you.  Use File\Open\Design from the menu to view your Schematic.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/OrcadCapture_BrdSch_import.html