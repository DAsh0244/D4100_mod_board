 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: Z:\\44\\82\\4482731\\6\Allegro\2019-06-19_12-06-50\2019-06-19_12-06-50
 
 
**********************************************************
*******************  PCB Instructions  *******************
**********************************************************

To import your new Board into Allegro:

1. Unzip the downloaded folder files to a local directory and
Using your Windows explorer, find the file that was included
in your zip file that ends in ".bat".  This is a batch file
set of instructions for your computer.  Double clicking this
file should start the batch file.  You must already have Allegro
installed on the computer that the batch file was
created on, or you will need to modify the pathing of the
batch file.
2. Use the Allegro PCB Design L (legacy) environment to open the PCB layout.
Be patient as it may take several minutes for Allegro execute the
".bat" file. If issues occur because of compatibility between releases,
click "Yes" to proceed to the next process. If this happens once, it will
happen for every footprint created and hault the ".bat" execution.
3. It will create more files for you by first loading the
padstack tool, and then the part building software.  The parts
will all be located in the directory the batch file was executed from
and will contain both the .DRA file, the .PSM file and any
other associated entities (like flash files and padstacks).
4. After the parts are built a board will be created, parts placed and
traces, vias, etc installed.  Once the board is completely built
the program will exit.
5. You will need to open Allegro up again and set your global
plane clearances and contact styles per your requirements.  In the case
of planes that are part of the library (such as under an SON style part)
you may need to create the planes manually and delete them from the
components.
6. Once completed, you will want to move the files that have
been created to your appropriate directory structure, so that
the parts are available for use in your board.

This requires that you have Allegro installed in the normal
locations and that it can be found in your pathing. If this
is not the case, simply edit the lines in your batch file that
refer to your Allegro tools to find them in the correct location.

You may be running a newer version of the Allegro Software than the
template file we are distributing.  In this case you will be asked
to okay the loading of the file each time the script requires a
file load.  You can update the template files found in the
\installationpath\CadInfos\Allegro\*.pcb files by simply opening
them in Allegro and then saving them again in your current version
of Allegro.  You should do this with the *.dra files as well.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Allegro_import.html

Additionally, this video may be helpful:
http://youtu.be/d1ixNGZUKjQ

**********************************************************
**********************************************************
**********************************************************
 
 
Padstack "RX62p99Y11p81D0TSM2" renamed to "RX62p99Y11p81D0TSM"
Component "GRM155R71C104KA88D" renamed to "GRM155R71C104KA88D"
Component "GRM033R60J223KE01D" renamed to "GRM033R60J223KE01D"
Component "GRM188R71H683KA93D" renamed to "GRM188R71H683KA93D"
Component "C1005X7S1A225K050BC" renamed to "C1005X7S1A225K050BC"
Component "GRM155R71A104KA01D" renamed to "GRM155R71A104KA01D"
Component "C5750X7S2A156M250KB" renamed to "C5750X7S2A156M250KB"
Component "C1608X5R1H105K080AB" renamed to "C1608X5R1H105K080AB"
Component "CL02C101JQ2ANNC" renamed to "CL02C101JQ2ANNC"
Component "GRM155R71E333KA88D" renamed to "GRM155R71E333KA88D"
Component "C1005X5R1V225K050BC" renamed to "C1005X5R1V225K050BC"
Component "PDS760-13" renamed to "PDS760-13"
Component "WB_GND" renamed to "WB_GND"
Component "XAL6030-122MEB" renamed to "XAL6030-122MEB"
Component "FDD8647L" renamed to "FDD8647L"
Component "CRCW04021K65FKED" renamed to "CRCW04021K65FKED"
Component "CRCW040235K7FKED" renamed to "CRCW040235K7FKED"
Component "CRCW040241K2FKED" renamed to "CRCW040241K2FKED"
Component "PRL1632-R006-F-T1" renamed to "PRL1632-R006-F-T1"
Component "CRCW04024K87FKED" renamed to "CRCW04024K87FKED"
Component "CRCW04023K57FKED" renamed to "CRCW04023K57FKED"
Component "RC0201FR-0710KL" renamed to "RC0201FR-0710KL"
Component "LM25088MH-1/NOPB" renamed to "LM25088MH-1NOPB"
Component "UMK105CG181JV-F" renamed to "UMK105CG181JV-F"
Component "CRCW040226K7FKED" renamed to "CRCW040226K7FKED"
Component "C0402C0G1C220K020BC" renamed to "C0402C0G1C220K020BC"
Component "CRCW04024K42FKED" renamed to "CRCW04024K42FKED"
Component "0101YA120JAT2A" renamed to "0101YA120JAT2A"
Component "WB_BATTERY" renamed to "WB_BATTERY"
Component "WB_CURRENT_LOAD" renamed to "WB_CURRENT_LOAD"
The Symbol WB_CONTINUATION was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CONTINUATION was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CONTINUATION was missing a Value attribute, a value was created for the symbol.
The Symbol WB_BLOCK_IO was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Type attribute, a type was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Value attribute, a value was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a Value attribute, a value was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_DIODE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_DIODE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_DIODE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LM25088 was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LM25088 was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LM25088 was missing a Value attribute, a value was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE1 was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE1 was missing a Type attribute, a type was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE1 was missing a Value attribute, a value was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE2 was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE2 was missing a Type attribute, a type was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE2 was missing a Value attribute, a value was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE3_VERT was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE3_VERT was missing a Type attribute, a type was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE3_VERT was missing a Value attribute, a value was created for the symbol.


Ultra Librarian Gold 8.1.204 Process Report


Message - Symbol "WB_CAPACITOR" has as multiple attributes named "RefDes".
One of the attributes was renamed to "REFDES_2".
Message - Symbol "WB_CAPACITOR" has as multiple attributes named "TYPE".
One of the attributes was renamed to "TYPE_2".
Message - Symbol "WB_CAPACITOR" has as multiple attributes named "Value".
One of the attributes was renamed to "VALUE_2".
Message - Component "GRM155R71C104KA88D" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71C104KA88D" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71C104KA88D" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71C104KA88D" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R60J223KE01D" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R60J223KE01D" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R60J223KE01D" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R60J223KE01D" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM188R71H683KA93D" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM188R71H683KA93D" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM188R71H683KA93D" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM188R71H683KA93D" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1005X7S1A225K050BC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1005X7S1A225K050BC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1005X7S1A225K050BC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1005X7S1A225K050BC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1005X7S1A225K050BC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71A104KA01D" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71A104KA01D" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71A104KA01D" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71A104KA01D" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C5750X7S2A156M250KB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C5750X7S2A156M250KB" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C5750X7S2A156M250KB" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C5750X7S2A156M250KB" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C5750X7S2A156M250KB" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H105K080AB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H105K080AB" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H105K080AB" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H105K080AB" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H105K080AB" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL02C101JQ2ANNC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL02C101JQ2ANNC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL02C101JQ2ANNC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL02C101JQ2ANNC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL02C101JQ2ANNC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71E333KA88D" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71E333KA88D" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71E333KA88D" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71E333KA88D" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1005X5R1V225K050BC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1005X5R1V225K050BC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1005X5R1V225K050BC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1005X5R1V225K050BC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1005X5R1V225K050BC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PDS760-13" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PDS760-13" attribute "Io" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PDS760-13" attribute "VRRM" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PDS760-13" attribute "VFatIo" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "XAL6030-122MEB" attribute "L" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "XAL6030-122MEB" attribute "DCR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "XAL6030-122MEB" attribute "IDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "FDD8647L" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "FDD8647L" attribute "VdsMax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "FDD8647L" attribute "IdsMax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "FDD8647L" attribute "Rdson45" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "FDD8647L" attribute "QgTyp" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "FDD8647L" attribute "Quantity" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04021K65FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04021K65FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04021K65FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040235K7FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040235K7FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040235K7FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040241K2FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040241K2FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040241K2FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PRL1632-R006-F-T1" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PRL1632-R006-F-T1" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PRL1632-R006-F-T1" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PRL1632-R006-F-T1" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04024K87FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04024K87FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04024K87FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04023K57FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04023K57FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04023K57FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0710KL" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0710KL" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0710KL" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0710KL" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1NOPB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1NOPB" attribute "Frequency" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1NOPB" attribute "Imax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1NOPB" attribute "Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1NOPB" attribute "Mktg_Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1NOPB" attribute "NSID" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "UMK105CG181JV-F" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "UMK105CG181JV-F" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "UMK105CG181JV-F" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "UMK105CG181JV-F" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "UMK105CG181JV-F" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040226K7FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040226K7FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040226K7FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0402C0G1C220K020BC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0402C0G1C220K020BC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0402C0G1C220K020BC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0402C0G1C220K020BC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0402C0G1C220K020BC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04024K42FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04024K42FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04024K42FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "0101YA120JAT2A" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "0101YA120JAT2A" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "0101YA120JAT2A" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "0101YA120JAT2A" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "0101YA120JAT2A" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.

TextStyle count:  24
Padstack count:   14
Pattern count:    11
Symbol count:     20
Component count:  29

Export

Starting to Export Allegro Padstacks
Starting to Export Allegro Parts
Exporting 0402
Exporting 0201
Exporting 0603
Exporting 0402_065
Exporting 2220_280
Exporting 01005
Exporting PowerDI5
Exporting XAL6030
Exporting DPAK
Exporting 0612
Exporting MXA16A
Completing output of Allegro netlist, placement and device files
