 
 
 
**********************************************************
*************  Important Instructions Follow  ************
**********************************************************
 
All files exported to: Z:\\44\\82\\4482731\\6\Eagle\2019-06-19_12-07-05\2019-06-19_12-07-05.xml
 
 
**********************************************************
*****************Schematic Instructions  *******************
**********************************************************

To import your new Schematic file into Eagle:

1. Unzip the downloaded folder files to local directory and Start Eagle.
2. Select "File"->"Open"->"Schematic..." from the menu at the top of
the screen.
3. Browse to your newly exported file and select the ".sch" file extension.
4. You should now see your schamtic available in Eagle.

**********************************************************
*******************  PCB Instructions  *******************
**********************************************************

To import your new BOARD file into Eagle:

1. Unzip the downloaded folder files to local directory and Start Eagle.
2. Select "File"->"Open"->"Board..." from the menu at the top of
the screen.
3. Browse to your newly exported file and select the ".brd" file extension.
4. Planes will need to be repoured to update the polygon fills
	1. Once your board is loaded, type "ratsnest" into the command
	   line and press the Enter key.
	2. The polygons should all be filled now.
5. You should now have an image of your board available in Eagle.

**********************************************************
*******************  LIB Instructions  *******************
**********************************************************

To import your new library into Eagle:

1. Start Eagle.
2. Select "File"->"New"->"Library" from the menu.
3. In the blank library window, select "File" -> "Execute Script"
from the menu.
5. Browse to your newly exported Eagle Script file (".scr" file extension)
6. After opening the file, the script will populate the new library.
Layer 93 should NOT exist.
7. Use "File"->Save As: "AcceleratedDesigns_Lib.lbr" and to the desired
location in Eagle native format.
8. Update schematic with the imported library, Select Library and click on Update; open the library file
	and sync. each part.

For additional information, please visit this site:
http://www.accelerated-designs.com/help/Eagle_import.html

You may also find this video helpful:
http://youtu.be/5jGuWY-Yy3Q

**********************************************************
**********************************************************
**********************************************************
 
 
Padstack "RX263p78Y299p4D0T" renamed to "RX263p78Y299p4D0"
Padstack "RX62p99Y11p81D0TSM2" renamed to "RX62p99Y11p81D00"
Padstack "RX118p11Y118p11D0T" renamed to "RX118p11Y118p11D"
Symbol "WB_COMPENSATION_BLOCK_TYPE3_VERT" renamed to "WB_COMPENSATION_BLOCK_TYPE3_VE"
Component "GRM155R71C104KA88D" renamed to "GRM155R71C104KA88D"
Component "GRM033R60J223KE01D" renamed to "GRM033R60J223KE01D"
Component "GRM188R71H683KA93D" renamed to "GRM188R71H683KA93D"
Component "C1005X7S1A225K050BC" renamed to "C1005X7S1A225K050BC"
Component "GRM155R71A104KA01D" renamed to "GRM155R71A104KA01D"
Component "C5750X7S2A156M250KB" renamed to "C5750X7S2A156M250KB"
Component "C1608X5R1H105K080AB" renamed to "C1608X5R1H105K080AB"
Component "CL02C101JQ2ANNC" renamed to "CL02C101JQ2ANNC"
Component "GRM155R71E333KA88D" renamed to "GRM155R71E333KA88D"
Component "C1005X5R1V225K050BC" renamed to "C1005X5R1V225K050BC"
Component "PDS760-13" renamed to "PDS760-13"
Component "WB_GND" renamed to "WB_GND"
Component "XAL6030-122MEB" renamed to "XAL6030-122MEB"
Component "FDD8647L" renamed to "FDD8647L"
Component "CRCW04021K65FKED" renamed to "CRCW04021K65FKED"
Component "CRCW040235K7FKED" renamed to "CRCW040235K7FKED"
Component "CRCW040241K2FKED" renamed to "CRCW040241K2FKED"
Component "PRL1632-R006-F-T1" renamed to "PRL1632-R006-F-T1"
Component "CRCW04024K87FKED" renamed to "CRCW04024K87FKED"
Component "CRCW04023K57FKED" renamed to "CRCW04023K57FKED"
Component "RC0201FR-0710KL" renamed to "RC0201FR-0710KL"
Component "LM25088MH-1/NOPB" renamed to "LM25088MH-1/NOPB"
Component "UMK105CG181JV-F" renamed to "UMK105CG181JV-F"
Component "CRCW040226K7FKED" renamed to "CRCW040226K7FKED"
Component "C0402C0G1C220K020BC" renamed to "C0402C0G1C220K020BC"
Component "CRCW04024K42FKED" renamed to "CRCW04024K42FKED"
Component "0101YA120JAT2A" renamed to "0101YA120JAT2A"
Component "WB_BATTERY" renamed to "WB_BATTERY"
Component "WB_CURRENT_LOAD" renamed to "WB_CURRENT_LOAD"
The Symbol WB_CONTINUATION was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CONTINUATION was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CONTINUATION was missing a Value attribute, a value was created for the symbol.
The Symbol WB_BLOCK_IO was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Type attribute, a type was created for the symbol.
The Symbol WB_BLOCK_IO was missing a Value attribute, a value was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a Type attribute, a type was created for the symbol.
The Symbol WB_SOURCE_RESISTOR was missing a Value attribute, a value was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a Type attribute, a type was created for the symbol.
The Symbol WB_PRIMITIVE_BATTERY was missing a Value attribute, a value was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_CURRENT_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_DIODE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_DIODE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_DIODE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_LM25088 was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_LM25088 was missing a Type attribute, a type was created for the symbol.
The Symbol WB_LM25088 was missing a Value attribute, a value was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_VOLTAGE_PROBE was missing a Value attribute, a value was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE1 was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE1 was missing a Type attribute, a type was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE1 was missing a Value attribute, a value was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE2 was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE2 was missing a Type attribute, a type was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE2 was missing a Value attribute, a value was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE3_VE was missing a RefDes attribute, a refdes was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE3_VE was missing a Type attribute, a type was created for the symbol.
The Symbol WB_COMPENSATION_BLOCK_TYPE3_VE was missing a Value attribute, a value was created for the symbol.


Ultra Librarian Gold 8.1.204 Process Report


Message - Padstack "RX22Y24D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX14Y13D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX26Y38D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX45Y213D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX55Y55D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX132Y191D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX56Y224D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX27p59Y83p12D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX263p78Y299p4D0" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX22Y132D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX62p99Y11p81D0T" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX62p99Y11p81D00" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "RX118p11Y118p11D" Shape(4) is a CIRCLE with no diameter.
Message - Padstack "R10080080000200A" Shape(4) is a CIRCLE with no diameter.
Message - Symbol "WB_CAPACITOR" has as multiple attributes named "RefDes".
One of the attributes was renamed to "REFDES_2".
Message - Symbol "WB_CAPACITOR" has as multiple attributes named "TYPE".
One of the attributes was renamed to "TYPE_2".
Message - Symbol "WB_CAPACITOR" has as multiple attributes named "Value".
One of the attributes was renamed to "VALUE_2".
Message - Component "GRM155R71C104KA88D" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71C104KA88D" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71C104KA88D" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71C104KA88D" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R60J223KE01D" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R60J223KE01D" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R60J223KE01D" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM033R60J223KE01D" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM188R71H683KA93D" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM188R71H683KA93D" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM188R71H683KA93D" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM188R71H683KA93D" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1005X7S1A225K050BC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1005X7S1A225K050BC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1005X7S1A225K050BC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1005X7S1A225K050BC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1005X7S1A225K050BC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71A104KA01D" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71A104KA01D" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71A104KA01D" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71A104KA01D" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C5750X7S2A156M250KB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C5750X7S2A156M250KB" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C5750X7S2A156M250KB" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C5750X7S2A156M250KB" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C5750X7S2A156M250KB" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H105K080AB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H105K080AB" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H105K080AB" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H105K080AB" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1608X5R1H105K080AB" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL02C101JQ2ANNC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL02C101JQ2ANNC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL02C101JQ2ANNC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL02C101JQ2ANNC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CL02C101JQ2ANNC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71E333KA88D" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71E333KA88D" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71E333KA88D" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "GRM155R71E333KA88D" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1005X5R1V225K050BC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1005X5R1V225K050BC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1005X5R1V225K050BC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1005X5R1V225K050BC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C1005X5R1V225K050BC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PDS760-13" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PDS760-13" attribute "Io" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PDS760-13" attribute "VRRM" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PDS760-13" attribute "VFatIo" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "XAL6030-122MEB" attribute "L" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "XAL6030-122MEB" attribute "DCR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "XAL6030-122MEB" attribute "IDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "FDD8647L" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "FDD8647L" attribute "VdsMax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "FDD8647L" attribute "IdsMax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "FDD8647L" attribute "Rdson45" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "FDD8647L" attribute "QgTyp" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "FDD8647L" attribute "Quantity" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04021K65FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04021K65FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04021K65FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040235K7FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040235K7FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040235K7FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040241K2FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040241K2FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040241K2FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PRL1632-R006-F-T1" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PRL1632-R006-F-T1" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PRL1632-R006-F-T1" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "PRL1632-R006-F-T1" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04024K87FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04024K87FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04024K87FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04023K57FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04023K57FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04023K57FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0710KL" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0710KL" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0710KL" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "RC0201FR-0710KL" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1/NOPB" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1/NOPB" attribute "Frequency" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1/NOPB" attribute "Imax" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1/NOPB" attribute "Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1/NOPB" attribute "Mktg_Package" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "LM25088MH-1/NOPB" attribute "NSID" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "UMK105CG181JV-F" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "UMK105CG181JV-F" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "UMK105CG181JV-F" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "UMK105CG181JV-F" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "UMK105CG181JV-F" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040226K7FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040226K7FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW040226K7FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0402C0G1C220K020BC" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0402C0G1C220K020BC" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0402C0G1C220K020BC" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0402C0G1C220K020BC" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "C0402C0G1C220K020BC" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04024K42FKED" attribute "Resistance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04024K42FKED" attribute "Power" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "CRCW04024K42FKED" attribute "Tolerance" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "0101YA120JAT2A" attribute "Datasheet URL" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "0101YA120JAT2A" attribute "Cap" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "0101YA120JAT2A" attribute "ESR" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "0101YA120JAT2A" attribute "IRMS" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.
Message - Component "0101YA120JAT2A" attribute "VDC" references text style "" that is not in the database.
The default pattern text style "H50s3" was substituted.

TextStyle count:  24
Padstack count:   14
Pattern count:    11
Symbol count:     20
Component count:  29

Export


Footprint "WB_GND" has no layer data mapped and will be skipped.
Component "WB_GND" requires footprint "WB_GND" and will be skipped.
Footprint "WB_BATTERY" has no layer data mapped and will be skipped.
Component "WB_BATTERY" requires footprint "WB_BATTERY" and will be skipped.
Footprint "WB_CURRENT_LOAD" has no layer data mapped and will be skipped.
Component "WB_CURRENT_LOAD" requires footprint "WB_CURRENT_LOAD" and will be skipped.
